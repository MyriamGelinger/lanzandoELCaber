package pruebas;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Test;

import lanzandoElCaber.Competencia;
import lanzandoElCaber.Lanzador;
import lanzandoElCaber.Lanzamiento;
import lanzandoElCaber.ManejoArchivos;
import lanzandoElCaber.Podio;

public class TestLanzandoElCaber {
	  
	/**
	 * Espacio para probar alg�n m�todo espec�fico.
	 * */
	
	@Test
	public void lanzamientoDescalificado() {
		Assert.assertEquals(0, (new Lanzamiento(100,100)).evaluarLanzamiento(),0.01);
		Assert.assertEquals(0, (new Lanzamiento(100,-100)).evaluarLanzamiento(),0.01);
		Assert.assertEquals(0, (new Lanzamiento(64,-92)).evaluarLanzamiento(),0.01);
	}
	
	@Test
	public void anguloSemiBien() {
		Assert.assertEquals(80, (new Lanzamiento(100,70)).evaluarLanzamiento(),0.01);
		Assert.assertEquals(80, (new Lanzamiento(100,-70)).evaluarLanzamiento(),0.01);
		Assert.assertEquals(51.2, (new Lanzamiento(64,77)).evaluarLanzamiento(),0.01);
	}

	@Test
	public void anguloBien() {
		Assert.assertEquals(100, (new Lanzamiento(100,30)).evaluarLanzamiento(),0.01);
		Assert.assertEquals(100, (new Lanzamiento(100,-30)).evaluarLanzamiento(),0.01);
		Assert.assertEquals(64.1, (new Lanzamiento(64.1f,27)).evaluarLanzamiento(),0.01);
	}


	
	
	@Test //caso ejemplo del enunciado
	public void testEjemploEnunciado() throws IOException { 
		
		String ruta = "src/pruebas/EntradaIN.txt"; 
		ArrayList<Lanzador> competidores = ManejoArchivos.leerArchivoIn(ruta);
		Competencia competencia = new Competencia(competidores);
		Podio podio = new Podio();
		podio.definirGanadoresConsistencia(competencia);
		podio.definirGanadoresDistancia(competencia);
		ManejoArchivos.grabarArchivoOut("src/pruebas/Salida.txt", podio.getGanadoresConsistencia(), podio.getGanadoresDistancia());
	    final File expected = new File("src/pruebas/SalidaEsperada"); 
	    final File output = new File ("src/pruebas/Salida.txt");  
	    Assert.assertEquals(FileUtils.readLines(expected), FileUtils.readLines(output)); 
	  }
	
	 
	@Test // caso en que no hay ganadores de consistencia
	public void testSinGanadores() throws IOException { 
		String ruta = "src/pruebas/EntradaIN2.txt"; 
		ArrayList<Lanzador> competidores = ManejoArchivos.leerArchivoIn(ruta);
		Competencia competencia = new Competencia(competidores);
		Podio podio = new Podio();
		podio.definirGanadoresConsistencia(competencia);
		podio.definirGanadoresDistancia(competencia);
		ManejoArchivos.grabarArchivoOut("src/pruebas/Salida2.txt", podio.getGanadoresConsistencia(), podio.getGanadoresDistancia());
	    final File expected = new File("src/pruebas/SalidaEsperada2"); 
	    final File output = new File ("src/pruebas/Salida2.txt");  
	    Assert.assertEquals(FileUtils.readLines(expected), FileUtils.readLines(output)); 
	  }

	@Test //caso en el que Ganan los dos �ltimos competidores en ese orden
	public void testSalidaEsperada3() throws IOException { 
		String ruta = "src/pruebas/EntradaIN3.txt"; 
		ArrayList<Lanzador> competidores = ManejoArchivos.leerArchivoIn(ruta);
		Competencia competencia = new Competencia(competidores);
		Podio podio = new Podio();
		podio.definirGanadoresConsistencia(competencia);
		podio.definirGanadoresDistancia(competencia);
		ManejoArchivos.grabarArchivoOut("src/pruebas/Salida3.txt", podio.getGanadoresConsistencia(), podio.getGanadoresDistancia());
	    final File expected = new File("src/pruebas/SalidaEsperada3"); 
	    final File output = new File ("src/pruebas/Salida3.txt");  
	    Assert.assertEquals(FileUtils.readLines(expected), FileUtils.readLines(output)); 
	  }
	
	@Test //Caso en el que todos participan en consistencia y se seleccionan solo 3 para el podio
	public void testSalidaEsperada4() throws IOException { 
		String ruta = "src/pruebas/EntradaIN4.txt"; 
		ArrayList<Lanzador> competidores = ManejoArchivos.leerArchivoIn(ruta);
		Competencia competencia = new Competencia(competidores);
		Podio podio = new Podio();
		podio.definirGanadoresConsistencia(competencia);
		podio.definirGanadoresDistancia(competencia);
		ManejoArchivos.grabarArchivoOut("src/pruebas/Salida4.txt", podio.getGanadoresConsistencia(), podio.getGanadoresDistancia());
	    final File expected = new File("src/pruebas/SalidaEsperada4"); 
	    final File output = new File ("src/pruebas/Salida4.txt");  
	    Assert.assertEquals(FileUtils.readLines(expected), FileUtils.readLines(output)); 
	  }
	
   @Test //Caso en el que Ganan los dos �ltimos competidores en orden invertido
	public void testSalidaEsperada5() throws IOException { 
		String ruta = "src/pruebas/EntradaIN5.txt"; 
		ArrayList<Lanzador> competidores = ManejoArchivos.leerArchivoIn(ruta);
		Competencia competencia = new Competencia(competidores);
		Podio podio = new Podio();
		podio.definirGanadoresConsistencia(competencia);
		podio.definirGanadoresDistancia(competencia);
		ManejoArchivos.grabarArchivoOut("src/pruebas/Salida5.txt", podio.getGanadoresConsistencia(), podio.getGanadoresDistancia());
		final File expected = new File("src/pruebas/SalidaEsperada5"); 
	    final File output = new File ("src/pruebas/Salida5.txt");  
	    Assert.assertEquals(FileUtils.readLines(expected), FileUtils.readLines(output)); 
	  }
	
   @Test //Algunos competidores tiran con �ngulo de 90 grados
	public void testSalidaEsperada6() throws IOException { 
		String ruta = "src/pruebas/EntradaIN6.txt"; 
		ArrayList<Lanzador> competidores = ManejoArchivos.leerArchivoIn(ruta);
		Competencia competencia = new Competencia(competidores);
		Podio podio = new Podio();
		podio.definirGanadoresConsistencia(competencia);
		podio.definirGanadoresDistancia(competencia);
		ManejoArchivos.grabarArchivoOut("src/pruebas/Salida6.txt", podio.getGanadoresConsistencia(), podio.getGanadoresDistancia());
		final File expected = new File("src/pruebas/SalidaEsperada6"); 
	    final File output = new File ("src/pruebas/Salida6.txt");  
	    Assert.assertEquals(FileUtils.readLines(expected), FileUtils.readLines(output)); 
	  }
	
	@Test //Caso Fatiga Ganan los 3 �ltimos competidores
	public void testFatiga() throws IOException { 
		String ruta = "src/pruebas/EntradaIN7.txt"; 
		ArrayList<Lanzador> competidores = ManejoArchivos.leerArchivoIn(ruta);
		Competencia competencia = new Competencia(competidores);
		Podio podio = new Podio();
		podio.definirGanadoresConsistencia(competencia);
		podio.definirGanadoresDistancia(competencia);
		ManejoArchivos.grabarArchivoOut("src/pruebas/Salida7.txt", podio.getGanadoresConsistencia(), podio.getGanadoresDistancia());
		final File expected = new File("src/pruebas/SalidaEsperada7"); 
	    final File output = new File ("src/pruebas/Salida7.txt");  
	    Assert.assertEquals(FileUtils.readLines(expected), FileUtils.readLines(output)); 
	  }
	
	@Test //Caso Fatiga Gana �ltimo competidor consistencia y distancia �l y dos mas del medio
	public void testFatiga1() throws IOException { 
		String ruta = "src/pruebas/EntradaIN8.txt"; 
		ArrayList<Lanzador> competidores = ManejoArchivos.leerArchivoIn(ruta);
		Competencia competencia = new Competencia(competidores);
		Podio podio = new Podio();
		podio.definirGanadoresConsistencia(competencia);
		podio.definirGanadoresDistancia(competencia);
		ManejoArchivos.grabarArchivoOut("src/pruebas/Salida8.txt", podio.getGanadoresConsistencia(), podio.getGanadoresDistancia());
		final File expected = new File("src/pruebas/SalidaEsperada8"); 
	    final File output = new File ("src/pruebas/Salida8.txt");  
	    Assert.assertEquals(FileUtils.readLines(expected), FileUtils.readLines(output)); 
	  }
	
	@Test //Caso Fatiga donde todos son tiros de 0 y 90 grados
	public void testFatiga2() throws IOException { 
		String ruta = "src/pruebas/EntradaIN9.txt"; 
		ArrayList<Lanzador> competidores = ManejoArchivos.leerArchivoIn(ruta);
		Competencia competencia = new Competencia(competidores);
		Podio podio = new Podio();
		podio.definirGanadoresConsistencia(competencia);
		podio.definirGanadoresDistancia(competencia);
		ManejoArchivos.grabarArchivoOut("src/pruebas/Salida9.txt", podio.getGanadoresConsistencia(), podio.getGanadoresDistancia());
		final File expected = new File("src/pruebas/SalidaEsperada9"); 
	    final File output = new File ("src/pruebas/Salida9.txt");  
	    Assert.assertEquals(FileUtils.readLines(expected), FileUtils.readLines(output)); 
	  }
	

	
}
