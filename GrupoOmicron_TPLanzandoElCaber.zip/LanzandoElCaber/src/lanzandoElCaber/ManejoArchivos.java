package lanzandoElCaber;

import java.io.*;
import java.util.*;

public class ManejoArchivos {

	public static ArrayList<Lanzador> leerArchivoIn(String ruta) {

		ArrayList<Lanzador> competidores = new ArrayList<Lanzador>();
		try {
			Scanner inScanner = new Scanner(new FileReader(ruta));
			int Cant_Competidores = inScanner.nextInt();
		
			
			double distancia, angulo;
			for (int j = 1; j <= Cant_Competidores; j++) {
				ArrayList<Lanzamiento> lanzamiento = new ArrayList<Lanzamiento>();
				for (int i = 1; i <= 3; i++) {
					//distancia = inScanner.nextFloat();
					distancia = Double.parseDouble(inScanner.next());
					//angulo = inScanner.nextFloat();
					angulo = Double.parseDouble(inScanner.next());
					lanzamiento.add(new Lanzamiento(distancia, angulo));
				}
				competidores.add(new Lanzador(j, lanzamiento));
			}

		inScanner.close();
		}
		
			catch (Exception ex) {
			ex.printStackTrace();
		}
		

		return competidores;
	}
	
	public static void grabarArchivoOut(String ruta, ArrayList<Integer> ganadoresConsistencia, ArrayList<Integer> ganadoresDistancia) {
		System.out.println("Ganadores Consistencia: " + ganadoresConsistencia);
		System.out.println("Ganadores Distancia: " + ganadoresDistancia);
		FileWriter fichero = null;
		 PrintWriter pw = null;
		 try
		 {
		 fichero = new FileWriter(ruta);
		 pw = new PrintWriter(fichero);
		 if(ganadoresConsistencia != null) {
		  pw.print(ganadoresConsistencia.get(0) );
		 for(int i = 1; i < ganadoresConsistencia.size(); i++) {
			//System.out.println(ganadoresConsistencia.get(i));
				pw.print(" " +ganadoresConsistencia.get(i) ) ;
			} 
		 }
		
		 else
		 {  
		
			 pw.print("No Hay Ganadores De Consistencia");
		 }
		 pw.println();
		 pw.print(ganadoresDistancia.get(0) ) ;
		 for(int i = 1; i < ganadoresDistancia.size(); i++) {
		       //System.out.println(ganadoresDistancia.get(i) );
				pw.print(" " +ganadoresDistancia.get(i)) ;
			}
		 } catch (Exception e) {
		 e.printStackTrace();
		 }
		 finally {
		 try {
		 if (null != fichero)
		 fichero.close();
		 }
		 catch (Exception e2) {
		 e2.printStackTrace();
		 }
		 }
		 }
		

	public static final int ARCHIVOS_IGUALES = 1;
	public static final int ARCHIVOS_DESIGUALES = 0;
	public static final int ERROR_LECTURA = -1;

	public static int compararArchivos(String pathFile1, String pathFile2) {
		int resultado = ARCHIVOS_IGUALES;
		try {
			Scanner lectorPrimerArchivo = new Scanner(new File(pathFile1));
			Scanner lectorSegundoArchivo = new Scanner(new File(pathFile2));

			String line1, line2;

			while (resultado == ARCHIVOS_IGUALES && lectorPrimerArchivo.hasNextLine()
					&& lectorSegundoArchivo.hasNextLine()) {

				line1 = lectorPrimerArchivo.nextLine();
				line2 = lectorSegundoArchivo.nextLine();

				if (!line1.equals(line2)) {
					resultado = ARCHIVOS_DESIGUALES;
				}
			}

			lectorPrimerArchivo.close();
			lectorSegundoArchivo.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			resultado = ERROR_LECTURA;
		}
		return resultado;
	}

}


