package lanzandoElCaber;

public class Lanzamiento {

	private double distancia;
	private double angulo;

	public Lanzamiento(double distancia, double angulo) {
		super();
		this.distancia = distancia;
		this.angulo = angulo;
	}

	public double getDistancia() {
		return distancia;
	}

	public double getAngulo() {
		return angulo;
	}

	public double evaluarLanzamiento() {
		int proporcion = 0;
		if (esLanzamientoValido()) {
			proporcion = angulo >= -30 && angulo <= 30 ? 100 : 80;
		}
		return distancia * proporcion / 100;
	}

	public boolean esLanzamientoValido() {
		return angulo >= -90 && angulo <= 90;
	}

	@Override
	public String toString() {
		return "Lanzamiento [distancia=" + distancia + ", angulo=" + angulo + "]";
	}

}