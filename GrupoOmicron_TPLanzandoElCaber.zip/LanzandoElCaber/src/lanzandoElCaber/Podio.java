package lanzandoElCaber;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Podio {
	
	private ArrayList<Integer> participaConsistencia;
	private ArrayList<Integer> ganadoresConsistencia;
	private ArrayList<Integer> ganadoresDistancia;
	
	public Podio() {
		ganadoresConsistencia = new ArrayList<Integer>();
		ganadoresDistancia = new ArrayList<Integer>();
	}
	//
	public ArrayList<Integer> getGanadoresConsistencia() {
		return ganadoresConsistencia;
	}

	public ArrayList<Integer> getGanadoresDistancia() {
		return ganadoresDistancia;
	}

	
	
	public ArrayList<Integer> definirGanadoresConsistencia(Competencia c) {
			ArrayList <Lanzador> arrLanzadores = c.getCompetidores();
			double toleranciaAngulo[] = new double[arrLanzadores.size()];
			double toleranciaDistancia[] = new double[arrLanzadores.size()];
			double mayorAngulo,menorAngulo, mayorDistancia, menorDistancia;
			int cantGanadores = arrLanzadores.size();
			
			mayorAngulo = mayorDistancia = -1;
			menorAngulo = 180;
			
			this.participaConsistencia = new ArrayList<Integer>();
			for(int i=0; i< arrLanzadores.size() ; i++) {
				Lanzador lanzador = arrLanzadores.get(i);
				
				if(lanzador.tieneLanzamientoDescalificado() == false) {///si tiene lanzamiento descalificado, no lo considero
					participaConsistencia.add(arrLanzadores.get(i).getId());//agregue yo 
					System.out.println("participa" +arrLanzadores.get(i).getId());
					menorDistancia = lanzador.getDistanciaEvaluadaTotal();
					
					for(Lanzamiento l : lanzador.getLanzamientos()) { ///saco tolerancia de sus angulos y distancias
						
						if(l.getDistancia() > mayorDistancia)
							mayorDistancia = l.getDistancia();
						if( Math.abs(l.getAngulo()) > mayorAngulo)
							mayorAngulo = l.getAngulo();
						if(l.getDistancia() < menorDistancia)
							menorDistancia = l.getDistancia();
						if(Math.abs(l.getAngulo()) > menorAngulo)
							menorAngulo = l.getAngulo();
					}
					
					toleranciaDistancia[i] = mayorDistancia - menorDistancia;
					toleranciaAngulo[i] = mayorAngulo - menorAngulo;
					
				} else 	cantGanadores--;
								
			}//for
			
			for(int i=0; i< arrLanzadores.size() ; i++) {
				Lanzador lanzador = arrLanzadores.get(i);				
				if(lanzador.tieneLanzamientoDescalificado() == false) {
				boolean seAgregoGanador = false;
				int j=0;
			
				while(seAgregoGanador == false && j < participaConsistencia.size()) {
					
					if(toleranciaDistancia[i] <= toleranciaDistancia[j] || 
					(toleranciaDistancia[i] == toleranciaDistancia[j] && toleranciaAngulo[i] < toleranciaAngulo[j])) {
						ganadoresConsistencia.add(j, arrLanzadores.get(i).getId());
						
						if(ganadoresConsistencia.size() >3) {	///para que no tenga mas de 3 en el podio
							ganadoresConsistencia.remove(3);
						}
						seAgregoGanador = true;
					}
					
					j++;
				}//while
				
				if(seAgregoGanador == false && j <3) ganadoresConsistencia.add(arrLanzadores.get(i).getId());
				
			}//if
		  }
		   	///comparo tolerancias
			
			if(cantGanadores == 0) 	ganadoresConsistencia = null;//Quiere decir que no hay ganadores
			
			return this.ganadoresConsistencia;
		}


	public ArrayList<Integer> definirGanadoresDistancia(Competencia c) {
		Collections.sort(c.getCompetidores(), new Comparator<Lanzador>() {

			@Override
			public int compare(Lanzador l1, Lanzador l2) { //mayor a menor
				return Double.compare(l2.getDistanciaEvaluadaTotal(), l1.getDistanciaEvaluadaTotal());
			}
			
		});

		this.ganadoresDistancia = new ArrayList<Integer>();
		for(int i = 0; i < Math.min(3,c.getCompetidores().size()); i++) {
			this.ganadoresDistancia.add(c.getCompetidores().get(i).getId());
		}
		return this.ganadoresDistancia;
	}
}
