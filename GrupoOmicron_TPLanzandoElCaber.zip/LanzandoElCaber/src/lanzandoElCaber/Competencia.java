package lanzandoElCaber;

import java.util.ArrayList;

public class Competencia {
	
	private ArrayList<Lanzador> competidores;

	public Competencia(ArrayList<Lanzador> competidores) {
		super();
		this.competidores = competidores;
	}

	public ArrayList<Lanzador> getCompetidores() {
		return competidores;
	}

	public void setCompetidores(ArrayList<Lanzador> competidores) {
		this.competidores = competidores;
	}
	
}
