package lanzandoElCaber;

import java.util.List;

public class Lanzador {

	private int id;

	private List<Lanzamiento> lanzamientos;

	public Lanzador() {

	}

	public Lanzador(int id, List<Lanzamiento> lanzamientos) {
		super();
		this.id = id;
		this.lanzamientos = lanzamientos;
	}

	public int getId() {
		return id;
	}

	public List<Lanzamiento> getLanzamientos() {

		return this.lanzamientos;
	}

	public double getDistanciaEvaluadaTotal() {
		double total = 0;
		for (Lanzamiento lanzamiento : lanzamientos) {
		//	System.out.println("lanzamientoevaluado" +lanzamiento.evaluarLanzamiento());
			total += lanzamiento.evaluarLanzamiento();
		
		}	
		
	return total;
	}

	public boolean tieneLanzamientoDescalificado() {
		boolean estaDescalificado = false;
		int index = 0;
		while (!estaDescalificado && index < lanzamientos.size()) {
			if (!lanzamientos.get(index).esLanzamientoValido())
				estaDescalificado = true;
			index++;
		}
		return estaDescalificado;
	}
	
	@Override
	public String toString() {
		return "Lanzador [id=" + id + ", lanzamientos=" + lanzamientos + "]";
	}

}
